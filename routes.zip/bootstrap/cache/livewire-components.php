<?php return array (
  'backend.browsinginformation-table' => 'App\\Http\\Livewire\\Backend\\BrowsinginformationTable',
  'backend.roles-table' => 'App\\Http\\Livewire\\Backend\\RolesTable',
  'backend.settings-table' => 'App\\Http\\Livewire\\Backend\\SettingsTable',
  'backend.users-table' => 'App\\Http\\Livewire\\Backend\\UsersTable',
  'frontend.two-factor-authentication' => 'App\\Http\\Livewire\\Frontend\\TwoFactorAuthentication',
  'frontend.url-table' => 'App\\Http\\Livewire\\Frontend\\UrlTable',
);