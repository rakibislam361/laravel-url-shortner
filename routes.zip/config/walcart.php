<?php


return [

  /*
    |--------------------------------------------------------------------------
    | Magento CMS API BASE URL
    |--------------------------------------------------------------------------
    */

  'magento_api_base' => env('MAGENTO_BASE_URL', 'https://avanteca.com.bd/walcart/rest/V1'),
  'magento_api_user' => env('MAGENTO_ADMIN_USERNAME', 'admin'),
  'magento_api_password' => env('MAGENTO_ADMIN_PASSWORD', 'Dhaka2021'),

];
